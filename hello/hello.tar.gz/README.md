# mkpm-hello

> mkpm hello world package
